from pathlib import Path
import asyncio
import pytest
from backend.api.routes import TemporaryFileResponse


def test_response_disconnect_removes_job(tmp_path):
    job = tmp_path / 'job-test'
    job.mkdir()
    target = job / 'result.md'
    target.write_text('valid markdown')
    response = TemporaryFileResponse(target, job=job, media_type='text/markdown')
    async def receive():
        return {'type': 'http.disconnect'}
    async def send(message):
        raise OSError('client disconnected')
    with pytest.raises(OSError):
        asyncio.run(response({'type': 'http', 'method': 'GET', 'headers': []}, receive, send))
    assert not job.exists()
