from io import BytesIO
import asyncio
import json
import os
from pathlib import Path
import time
import zipfile
import pytest
import pymupdf
from PIL import Image
from backend.config import TEMP_ROOT, MAX_FILE_SIZE
from backend.services.file_detector import detect_extension, output_name
from backend.services.errors import ConversionError
from backend.services.table_detector import typed_value
from backend.services.temporary_files import cleanup_stale
from backend.tests.test_initial_flows import convert


@pytest.mark.parametrize('name,expected', [('ABC.PDF', 'pdf'), ('dados.MHTML', 'mhtml'), ('a.docx', 'docx')])
def test_extension(name, expected):
    assert detect_extension(name) == expected


def test_unsupported_extension():
    with pytest.raises(ConversionError):
        detect_extension('virus.pdf.exe')


def test_safe_name():
    assert output_name('../../Relatório.pdf', 'md') == 'Relatório.md'
    assert output_name('C:\\secret\\report.pdf', 'xlsx') == 'report.xlsx'
    assert '\r' not in output_name('report\r\n.pdf', 'md')


@pytest.mark.parametrize('filename,mime,content,output,status', [
    ('invalid.pdf', 'application/pdf', b'not a pdf', 'md', 422),
    ('invalid.docx', 'application/zip', b'not a zip', 'md', 422),
    ('invalid.mht', 'message/rfc822', b'<table>not MIME</table>', 'xlsx', 422),
    ('empty.pdf', 'application/pdf', b'', 'md', 422),
    ('virus.exe', 'application/octet-stream', b'exe', 'md', 400),
    ('report.pdf', 'application/pdf', b'text', '../../exe', 400),
])
def test_invalid_files_cleanup(client, filename, mime, content, output, status):
    response = client.post('/api/convert', files={'file': (filename, content, mime)}, data={'output_format': output})
    assert response.status_code == status, response.text
    assert 'Traceback' not in response.text
    assert not list(TEMP_ROOT.glob('job-*'))


def test_mime_mismatch(client, pdf):
    response = convert(client, pdf, 'md', 'application/x-executable')
    assert response.status_code == 422
    assert 'tipo de conteúdo' in response.json()['detail']


def test_too_large(client):
    response = client.post('/api/convert', files={'file': ('big.pdf', b'0' * (MAX_FILE_SIZE + 1), 'application/pdf')}, data={'output_format': 'md'})
    assert response.status_code == 413
    assert not list(TEMP_ROOT.glob('job-*'))


def test_request_body_limit(client):
    response = client.post('/api/convert', content=b'x', headers={'Content-Length': str(MAX_FILE_SIZE + 2 * 1024 * 1024)})
    assert response.status_code == 413


def test_chunked_body_limit(client):
    def chunks():
        yield b'--boundary\r\nContent-Disposition: form-data; name="file"; filename="large.pdf"\r\nContent-Type: application/pdf\r\n\r\n'
        for _ in range(27):
            yield b'x' * 1024 * 1024
        yield b'\r\n--boundary--\r\n'
    response = client.post('/api/convert', content=chunks(), headers={'Content-Type': 'multipart/form-data; boundary=boundary'})
    assert response.status_code == 413, response.text
    assert not list(TEMP_ROOT.glob('job-*'))


def test_zip_bomb(client):
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('[Content_Types].xml', '<Types/>')
        archive.writestr('word/document.xml', b'0' * (51 * 1024 * 1024))
    response = client.post('/api/convert', files={'file': ('bomb.docx', buffer.getvalue(), 'application/zip')}, data={'output_format': 'md'})
    assert response.status_code == 422
    assert not list(TEMP_ROOT.glob('job-*'))


def test_protected_pdf(client, pdf, tmp_path):
    target = tmp_path / 'locked.pdf'
    with pymupdf.open(pdf) as doc:
        doc.save(target, encryption=pymupdf.PDF_ENCRYPT_AES_256, owner_pw='owner', user_pw='secret')
    response = convert(client, target, 'md', 'application/pdf')
    assert response.status_code == 422
    assert 'senha' in response.json()['detail']


def test_no_tables(client, tmp_path):
    target = tmp_path / 'no-tables.pdf'
    with pymupdf.open() as doc:
        page = doc.new_page()
        page.insert_text((50, 80), 'A single sentence, without tabular data.')
        doc.save(target)
    response = convert(client, target, 'xlsx', 'application/pdf')
    assert response.status_code == 422
    assert 'tabelas' in response.json()['detail']


def test_scan_detected_and_word_fallback(client, tmp_path):
    target = tmp_path / 'scan.pdf'
    picture = BytesIO()
    Image.new('RGB', (300, 400), 'white').save(picture, format='PNG')
    with pymupdf.open() as doc:
        page = doc.new_page()
        page.insert_image(page.rect, stream=picture.getvalue())
        doc.save(target)
    for output in ('md', 'xlsx'):
        response = convert(client, target, output, 'application/pdf')
        assert response.status_code == 422
        assert 'digitalizadas' in response.json()['detail']
    response = convert(client, target, 'docx', 'application/pdf')
    assert response.status_code == 200
    from docx import Document
    assert len(Document(BytesIO(response.content)).inline_shapes) == 1


def test_timeout_and_cleanup(client, pdf, monkeypatch):
    from backend.api import routes
    monkeypatch.setattr(routes, 'CONVERSION_TIMEOUT', 0.001)
    response = convert(client, pdf, 'md', 'application/pdf')
    assert response.status_code == 504
    assert not list(TEMP_ROOT.glob('job-*'))


def test_capacity(client, pdf, monkeypatch):
    from backend.api import routes
    monkeypatch.setattr(routes, 'slots', asyncio.Semaphore(0))
    response = convert(client, pdf, 'md', 'application/pdf')
    assert response.status_code == 429
    assert not list(TEMP_ROOT.glob('job-*'))


def test_stale_cleanup():
    old = TEMP_ROOT / 'job-stale'
    fresh = TEMP_ROOT / 'job-fresh'
    old.mkdir(); fresh.mkdir()
    os.utime(old, (time.time() - 3700, time.time() - 3700))
    cleanup_stale()
    assert not old.exists()
    assert fresh.exists()
    fresh.rmdir()


@pytest.mark.parametrize('value,expected', [('00123', '00123'), ('1.234', '1.234'), ('1.234,56', 1234.56), ('1,234.56', 1234.56), ('(150,50)', -150.5), ('25%', .25), ('', None), ('12345678901234567', '12345678901234567')])
def test_numeric_semantics(value, expected):
    assert typed_value(value)[0] == expected


def test_formats_and_config(client):
    assert client.get('/api/formats').json()['pdf'] == ['md', 'docx', 'xlsx', 'pptx']
    assert client.get('/api/config').json()['max_file_size_mb'] == 25
    assert client.get('/api/health').json() == {'status': 'ok'}
