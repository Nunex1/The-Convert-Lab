"""One isolated process per conversion; no user filenames or content in logs."""
import json
import logging
import sys
from pathlib import Path
from backend.converters.registry import get_converter
from backend.services.file_validator import validate_file
from backend.services.result_validator import validate_result
from backend.services.errors import ConversionError


def run(job: Path):
    options = json.loads((job / 'request.json').read_text(encoding='utf-8'))
    source, target = job / ('input.' + options['input']), job / ('result.' + options['output'])
    try:
        validate_file(source, options['input'], options['mime'])
        warnings = get_converter(options['input'], options['output'])(source, target)
        validate_result(target, options['output'])
        result = {'ok': True, 'warnings': warnings}
    except ConversionError as error:
        result = {'ok': False, 'message': str(error), 'code': 'invalid_document'}
    except Exception as error:
        result = {'ok': False, 'message': 'Não foi possível concluir a conversão. Verifique o documento e tente novamente.', 'code': type(error).__name__}
    (job / 'status.json').write_text(json.dumps(result, ensure_ascii=False), encoding='utf-8')


if __name__ == '__main__':
    logging.disable(logging.CRITICAL)
    run(Path(sys.argv[1]))
